#!/usr/bin/env python
import gym
import gym_gvgai
import Agent as Agent
games = ['gvgai-treasurekeeper']
validateLevels = ['lvl0-v0', 'lvl1-v0']
totalTimes = 20

# variables for recording the results
results = {}

for game in games:
	levelRecord = {}
	for level in validateLevels:
		timeRecord = {}
		for t in range(totalTimes):
			env = gym_gvgai.make(game + '-' + level)
			agent = Agent.Agent()
			print('Starting ' + env.env.game + " with Level " + str(env.env.lvl))
			stateObs = env.reset()
			actions = env.unwrapped.get_action_meanings()
			totalScore = 0
			for tick in range(2000):
				print(tick)
				action_id = agent.act(stateObs, actions)
				stateObs, diffScore, done, debug = env.step(action_id)
				totalScore += diffScore
				if done:
					break
			timeRecord[t] = [tick, totalScore, debug["winner"]]
			print(tick, totalScore, debug["winner"])      
		levelRecord[level] = timeRecord
	results[game] = levelRecord
filename = agent.name + "_result.txt"
with open(filename,'w') as f:
	f.write(str(results))