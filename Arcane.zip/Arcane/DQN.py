import gym_gvgai as gvg
import tensorflow.compat.v1 as tf
tf.disable_eager_execution()
import numpy as np
import random
from collections import deque
from recognition.identifier import Identifier
# Hyper Parameters for DQN
GAMMA = 0.9 # discount factor for target Q
INITIAL_EPSILON = 1.0 # starting value of epsilon
FINAL_EPSILON = 0.1 # final value of epsilon
EPSILON_CONTROL=100000
REPLAY_SIZE = 60000 # experience replay buffer size
BATCH_SIZE = 32 # size of minibatch
LEARN_RATE = 0.001

# # 定义神经网络结构相关参数
# INPUT_NODE =  32*32 # 28*28=784
# OUTPUT_NODE = 10
#
# IMAGE_SIZE = 28
# 第一层卷积层的尺寸和深度
CONV1_DEEP = 32
CONV1_SIZE = 4

# 第二层卷积层的尺寸和深度
CONV2_DEEP = 64
CONV2_SIZE = 2

# 第一层卷积层的尺寸和深度
CONV3_DEEP = 32
CONV3_SIZE = 2
class NET():
  # DQN Agent
  def __init__(self, game, stateObs, action_n):
    # init experience replay
    self.replay_buffer = deque()
    # init some parameters
    self.time_step = 0
    self.epsilon = INITIAL_EPSILON
    self.elm_size = 16
    self.state_dim = [stateObs.shape[0]//10*2+1,stateObs.shape[1]//10*2+1,16]
    self.num_channel = 16
    self.action_dim = action_n
    self.train_cnt=0
    self.loss=0
    self.create_Q_network()
    self.create_training_method()

    # Init session
    self.session = tf.InteractiveSession()
    self.session.run(tf.initialize_all_variables())
    #init identify
    self.idfy = Identifier(stateObs,'recognition/identifier/%s.json' % game)
  def create_Q_network(self):
    self.state_input = tf.placeholder(
      "float",
      [None, self.state_dim[0], self.state_dim[1],self.state_dim[2]]
    )
    self.sur_info= tf.placeholder(
      "float",
      [None,5, 5,self.state_dim[2]]
    )

    with tf.variable_scope('layer1-conv1'):
      conv1_weight = tf.get_variable(
        'weight',[CONV1_SIZE, CONV1_SIZE, self.num_channel, CONV1_DEEP],
        initializer=tf.truncated_normal_initializer(stddev=0.1)
      )
      conv1_biases = tf.get_variable(
        'bias', [CONV1_DEEP],
        initializer= tf.constant_initializer(0.0)
      )
      conv1 = tf.nn.conv2d(
        self.state_input, conv1_weight, strides=[1,3,3,1],padding='SAME'
      )
      relu1 = tf.nn.relu(tf.nn.bias_add(conv1, conv1_biases))
    with tf.variable_scope('layer2-conv2'):
      conv2_weights = tf.get_variable(
        'weight', [CONV2_SIZE, CONV2_SIZE, CONV1_DEEP, CONV2_DEEP],
        initializer=tf.truncated_normal_initializer(stddev=0.1)
      )
      conv2_biases = tf.get_variable(
        'bias', [CONV2_DEEP],
        initializer=tf.constant_initializer(0.0)
      )
      conv2 = tf.nn.conv2d(
        relu1, conv2_weights, strides=[1, 2, 2, 1], padding='SAME'
      )
      relu2 = tf.nn.relu(tf.nn.bias_add(conv2, conv2_biases))
    # with tf.name_scope('layer4-pool2'):
    #   pool2 = tf.nn.max_pool(
    #     relu2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME'
    #   )
    # with tf.name_scope('layer4-pool2'):
    #   pool2 = tf.nn.avg_pool(
    #     self.state_input, ksize=[1, 4, 4, 1], strides=[1, 4, 4, 1], padding='SAME'
    #   )
    pool_shape = relu2.get_shape().as_list()
      # network weights
    nodes = pool_shape[1] * pool_shape[2] * pool_shape[3]
    reshaped = tf.reshape(relu2, [-1, nodes])

    with tf.variable_scope('layer3-conv3'):
      conv3_weight = tf.get_variable(
        'weight',[CONV3_SIZE, CONV3_SIZE, self.num_channel, CONV3_DEEP],
        initializer=tf.truncated_normal_initializer(stddev=0.1)
      )
      conv3_biases = tf.get_variable(
        'bias', [CONV3_DEEP],
        initializer= tf.constant_initializer(0.0)
      )
      conv3 = tf.nn.conv2d(
        self.sur_info, conv3_weight, strides=[1,1,1,1],padding='SAME'
      )
      relu3 = tf.nn.relu(tf.nn.bias_add(conv3, conv3_biases))


    pool_shape2=relu3.get_shape().as_list()
    nodes2 = pool_shape2[1] * pool_shape2[2] * pool_shape2[3]
    reshaped2 = tf.reshape(relu3, [-1, nodes2])

    W1 = self.weight_variable([nodes,256])
    b1 = self.bias_variable([256])

    W2  = self.weight_variable([nodes2,256])
    b2 = self.bias_variable([256])

    W3  = self.weight_variable([256+256,64])
    b3 = self.bias_variable([64])

    W4 = self.weight_variable([64,self.action_dim])
    b4 = self.bias_variable([self.action_dim])

    # hidden layers
    h_layer1 = tf.nn.relu(tf.matmul(reshaped,W1) + b1)
    h_layer2= tf.nn.relu(tf.matmul(reshaped2,W2) + b2)
    next_shape = tf.concat([h_layer1, h_layer2], axis=1)
    h_layer3 = tf.nn.relu(tf.matmul(next_shape,W3) + b3)
    # Q Value layer
    self.Q_value = tf.matmul(h_layer3,W4) + b4
  def create_training_method(self):
    self.action_input = tf.placeholder("float",[None,self.action_dim]) # one hot presentation
    self.y_input = tf.placeholder("float",[None])
    Q_action = tf.reduce_sum(tf.multiply(self.Q_value,self.action_input),reduction_indices = 1)
    self.cost = tf.reduce_mean(tf.square(self.y_input - Q_action))
    self.optimizer = tf.train.AdamOptimizer(LEARN_RATE).minimize(self.cost)

  def perceive(self,state,action,reward,next_state,done):
    one_hot_action = np.zeros(self.action_dim)
    one_hot_action[action] = 1
    state,state_sur=self.idfy.identify(state)
    next_state,next_state_sur=self.idfy.identify(next_state)
    self.replay_buffer.append(((state,state_sur),one_hot_action,reward,(next_state,next_state_sur),done))
    if len(self.replay_buffer) > REPLAY_SIZE:
      self.replay_buffer.popleft()
    if len(self.replay_buffer) > BATCH_SIZE:
      if(self.train_cnt==0):
        self.train_Q_network()
      self.train_cnt+=1
      self.train_cnt%=8

  def train_Q_network(self):
    self.time_step += 1
    # Step 1: obtain random minibatch from replay memory
    minibatch = random.sample(self.replay_buffer,BATCH_SIZE)
    state_batch = [data[0][0] for data in minibatch]
    state_sur_batch = [data[0][1] for data in minibatch]
    action_batch = [data[1] for data in minibatch]
    reward_batch = [data[2] for data in minibatch]
    next_state_batch = [data[3][0] for data in minibatch]
    next_state_sur_batch = [data[3][1] for data in minibatch]

    # Step 2: calculate y
    y_batch = []
    Q_value_batch = self.Q_value.eval(feed_dict={self.state_input:next_state_batch, self.sur_info:next_state_sur_batch})
    for i in range(0,BATCH_SIZE):
      done = minibatch[i][4]
      if done:
        y_batch.append(reward_batch[i])
      else :
        y_batch.append(reward_batch[i] + GAMMA * np.max(Q_value_batch[i]))

    _loss,_Qval,_=self.session.run([self.cost,self.Q_value,self.optimizer],feed_dict={
      self.y_input:y_batch,
      self.action_input:action_batch,
      self.state_input:state_batch,
      self.sur_info:state_sur_batch
      })
    global  loss_list
    global  Qval_list
    loss_list.append(_loss)
    Qval_list.append(np.max(_Qval))
  def egreedy_action(self,state):
    state,sur_info = self.idfy.identify(state)
    if self.epsilon>FINAL_EPSILON:
      self.epsilon -= (INITIAL_EPSILON - FINAL_EPSILON) / EPSILON_CONTROL
    Q_value = self.Q_value.eval(feed_dict = {
      self.state_input:[state],
      self.sur_info:[sur_info]
      })[0]
    if random.random() <= self.epsilon:
      return random.randint(0,self.action_dim - 1)
    else:
      return self.select_soft(Q_value)

  def select_soft(self,Q_value,a=1):
    e = np.exp(1)
    pos_val=np.array(Q_value,dtype=float)
    #pos_val=np.clip(pos_val,-200.0,200.0)
    pos_val = pos_val-(max(pos_val)-20)
    pos_val=(e**pos_val)/sum(e**pos_val)
    x=random.random()
    t=0
    while(x>=pos_val[t]):
      x-=pos_val[t]
      t+=1
    return t
  def action(self,state,a=1):
    state,sur_info=self.idfy.identify(state)
    res = self.Q_value.eval(feed_dict = {
      self.state_input:[state],
      self.sur_info: [sur_info]
      })[0]
    #print(res)
    res=self.select_soft(res,a)
    #print(res)
    return res
  def weight_variable(self,shape):
    initial = tf.truncated_normal(shape,stddev=0.1)
    return tf.Variable(initial)
  def bias_variable(self,shape):
    initial = tf.constant(0.1, shape = shape)
    return tf.Variable(initial)
