import gym_gvgai as gvg
from recognition.identifier import Identifier
import numpy as np
gameName = 'golddigger'

if __name__ == '__main__':
    xs = np.array([4, 4, 4, 4, 4, 1, 3, 5, 7, 9]) + np.array([70] * 10)
    ys = np.array([0, 2, 4, 6, 8, 5, 5, 5, 5,5]) + np.array([80] * 10)
    env = gvg.make('gvgai-%s-lvl1-v0' % gameName)
    idfy = Identifier()
    idfy.load('identifier/golddigger.json')

    pc = idfy.playerCode

    pixels = env.reset()
    keyv = ''
    for k in range(10):
        tmp = 0
        for l in range(3):
            tmp += pixels[xs[k], ys[k], l]
        keyv += str(tmp // 3)
        if k < 9: keyv += ','
    print(idfy.main[keyv])

    for i in range(2,6):
        pixels, _, _, _ = env.step(i)
        keyv = ''
        for k in range(10):
            tmp = 0
            for l in range(3):
                tmp += pixels[xs[k], ys[k], l]
            keyv += str(tmp // 3)
            if k < 9: keyv += ','
        idfy.main[keyv] = 16-i
        print(keyv,16-i)
    idfy.save('identifier/%s.json' % gameName)
