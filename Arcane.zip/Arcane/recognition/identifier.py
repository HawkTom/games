import gym_gvgai as gvg
import time
import numpy as np
import json
elm_size=16
def buildIdentifier(game, lvls):
    res = Identifier()
    visit = {}
    total = 1
    for l in lvls:
        print(l)
        with open('./level_txt/%s/%s.txt' % (game, l), 'r') as f:
            lvl = str.split(f.read(), '\n')
        env = gvg.make('gvgai-%s-%s-v0' % (game, l))
        pixels = env.reset()

        h, w = len(pixels)//10, len(pixels[0])//10
        for i in range(h):
            for j in range(w):
                t = lvl[i][j]
                if t not in visit:
                    if t == 'A':
                        res.main['A'] = elm_size-1
                        visit[t] = elm_size-1
                    else:
                        visit[t] = total
                        print(t,total)
                        total += 1
                xs = res.axisx + np.array([i*10]*10)
                ys = res.axisy + np.array([j*10]*10)
                #val = ( sum(pixels[xs, ys, 0])+sum(pixels[xs, ys, 1])+sum(pixels[xs, ys, 2]))//25
                keyv=''
                for k in range(10):
                    tmp=0
                    for l in range(3):
                        tmp+=pixels[xs[k],ys[k],l]
                    keyv+=str(tmp//3)
                    if k<9:keyv+=','
                if(t=='A'):
                    print(pixels[xs, ys, 0],pixels[xs, ys, 1],pixels[xs, ys, 2])
                    print(keyv)
                res.main[keyv] = visit[t]
    return res

class Identifier:
    axisx = np.array([4,4,4,4,4,1,3,5,7,9])
    axisy = np.array([0,2,4,6,8,5,5,5,5,5])
    def __init__(self,img,fileName):
        self.main = {}
        self.elm = []
        self.val = []
        self.playerx=0
        self.playery=0
        self.h = len(img)//10
        self.w = len(img[0])//10
        with open(fileName, 'r') as file:
            self.main = json.load(file)
        for key in self.main:
            if key=='A':continue
            val = key.split(',')
            tmp=np.empty(10)
            for i in range(10):
                tmp[i]=int(val[i])
            mat = np.empty((self.h,self.w,10))
            mat[:,:]=tmp
            self.elm.append(mat)
            self.val.append(self.main[key])
    def identify(self, img):
        #start = time.process_time_ns()
        #img = np.array(img)
        h, w = len(img)//10, len(img[0])//10
        elm_mat = np.empty((h,w,10),dtype=int)
        for i in range(h):
            for j in range(w):
                xs = self.axisx + np.array([i * 10] * 10)
                ys = self.axisy + np.array([j * 10] * 10)
                elm_mat[i][j]=np.sum(img[xs,ys,0:3],axis=1)
        elm_mat=elm_mat//3
        dif_mat = np.empty((h,w,len(self.elm)))
        for i in range(len(self.elm)):
            dif_mat[:,:,i]=np.sum(abs(elm_mat-self.elm[i]),axis=2)
        res = np.argmin(dif_mat,axis=2)
        for i in range(h):
            for j in range(w):
                res[i][j]=self.val[res[i][j]]
                if 11 <= res[i][j] <= 15:
                    self.playerx = i + h
                    self.playery = j + w
        res=np.lib.pad(res,((h,h),(w,w)),'constant',constant_values=0)
        mat1=res[self.playerx-h:self.playerx+h+1 , self.playery-w:self.playery+w+1]
        mat2 = res[self.playerx-2:self.playerx+3, self.playery-2:self.playery+3]
        mat1=np.eye(elm_size)[mat1]
        mat2=np.eye(elm_size)[mat2]
        # out=np.argmax(mat1,axis=2)
        # print()
        # for i in range(len(out)):
        #     for j in range(len(out[0])):
        #         print(out[i][j], end=" ")
        #     print()
        return mat1,mat2
    def save(self, fileName):
        with open(fileName, 'w') as file:
            json.dump(self.main, file)
    def __getattr__(self, item):
        if item == 'playerCode':
            return self.main['A']
        else:
            raise AttributeError('Unknown attribute : %s' % item)