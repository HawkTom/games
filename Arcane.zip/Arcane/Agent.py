import tensorflow.compat.v1 as tf
import gym_gvgai as gvg
from DQN import NET
import DQN
from random import randint


class Agent():
    def __init__(self):
        self.name = "DQNAgent"
        self.ready = False
        self.n_actions = 0
        self.game = "waterpuzzle"
        self.agent = None
        self.path = ""
    def __del__(self):
        if self.game !="waterpuzzle":
            if self.agent != None:
              self.agent.session.close()
    def act(self, stateObs, actions):
        if not self.ready:
            self.get_ready(stateObs,actions)
        if self.game=="waterpuzzle":
            return randint(0, len(actions) - 1)
        else:
            return self.agent.action(stateObs)
    def get_ready(self, stateObs, actions):
        self.n_actions = len(actions)
        if stateObs.shape[0] == 150:
            self.game = "golddigger"
            self.path = "./1/model.ckpt-500"
        elif stateObs.shape[0] == 90:
            self.game = "treasurekeeper"
            self.path = "./2/model.ckpt-2450"
        else:
            self.game = "waterpuzzle"
        self.ready = True
        if self.game !="waterpuzzle":
            #tf.reset_default_graph()
            tf.reset_default_graph()
            self.agent = NET(self.game, stateObs,self.n_actions)   
            saver = tf.train.Saver()
            saver.restore(self.agent.session, self.path)