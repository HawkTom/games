Our agent **Arcane** is trained using DQN algorithm.  **Arcane** recognizes the image as element matrix and divides it into two parts: global view and surrounding view. And three nets with the same structure are trained for the three games.  **Arcane** performs well in the first game golddigger especially.  

